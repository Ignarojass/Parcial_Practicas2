-- Crear base de datos
CREATE DATABASE IF NOT EXISTS tienda
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE tienda;

-- Tabla de productos
CREATE TABLE IF NOT EXISTS productos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    precio DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    imagen VARCHAR(255) NOT NULL DEFAULT 'default.jpg',
    stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar productos
INSERT INTO productos (nombre, precio, imagen, stock) VALUES
('Gorra Deportiva', 15.00, 'gorra1.jpg', 8),
('Gorra Vintage', 20.00, 'gorra2.jpg', 0),
('Gorra de River', 30.00, 'gorra3.jpg', 18),
('Gorra de Boca', 30.00, 'gorra4.jpg', 12),
('Gorra de Pescador', 50.00, 'gorra5.jpg', 15),
('Gorra Tumafire', 25.00, 'tumafire.jpg', 16),
('Gorra Tumafire 2', 25.00, 'tumafire2.jpg', 9),
('Gorra Tumafire 3', 25.00, 'tumafire3.jpg', 14);

-- Tabla Clientes
CREATE TABLE clientes (
    id_cliente INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    direccion VARCHAR(255),
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla Pedidos
CREATE TABLE pedidos (
    id_pedido INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT UNSIGNED,
    fecha_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado ENUM('Pendiente', 'Procesando', 'Enviado', 'Completado') NOT NULL DEFAULT 'Pendiente',
    total DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);

-- Tabla Detalle_Pedido
CREATE TABLE detalle_pedido (
    id_detalle INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT UNSIGNED,
    id_producto INT UNSIGNED,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido),
    FOREIGN KEY (id_producto) REFERENCES productos(id)
);

-- Insertar clientes
INSERT INTO clientes (nombre, apellido, email, direccion) VALUES
('Ana', 'García', 'ana.garcia@email.com', 'Calle Falsa 123'),
('Luis', 'Martínez', 'luis.martinez@email.com', 'Av. Siempre Viva 742');

-- Pedido 1 (Ana)
INSERT INTO pedidos (id_cliente, total) VALUES (1, 45.00);
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(1, 1, 1, 15.00),
(1, 3, 1, 30.00);

-- Pedido 2 (Luis)
INSERT INTO pedidos (id_cliente, total) VALUES (2, 50.00);
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(2, 7, 2, 25.00);