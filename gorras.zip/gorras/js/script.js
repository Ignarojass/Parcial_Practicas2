// js/script.js
document.querySelector('form')?.addEventListener('submit', function (e) {
  e.preventDefault();
  alert('Formulario enviado. ¡Gracias por contactarnos!');
});
