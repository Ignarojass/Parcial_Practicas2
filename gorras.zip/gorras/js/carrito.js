// js/carrito.js
document.addEventListener('DOMContentLoaded', () => { 
  mostrarCarrito(); 
});

let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
const container = document.getElementById("carrito-container");
const totalElemento = document.getElementById("total");
const subtotalElemento = document.getElementById("subtotal");
const cartCountElement = document.getElementById("cart-item-count");

function mostrarCarrito() {
  container.innerHTML = "";
  let total = 0;

  if (carrito.length === 0) {
    container.innerHTML = `
      <div class="empty-cart">
        <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="9" cy="21" r="1"></circle>
          <circle cx="20" cy="21" r="1"></circle>
          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
        </svg>
        <h3>Tu carrito está vacío</h3>
        <p>Agrega productos para comenzar tu compra</p>
        <a href="gorras.php" class="btn-shop-now">
          <span>Explorar Productos</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="9 18 15 12 9 6"></polyline>
          </svg>
        </a>
      </div>
    `;
    actualizarTotales(0);
    actualizarContador();
    deshabilitarBotones(true);
    return;
  }

  carrito.forEach((p, index) => {
    const cantidad = Number(p.cantidad || 1);
    const precio = Number(p.precio);
    const subtotal = precio * cantidad;
    
    const div = document.createElement("div");
    div.classList.add("cart-item");
    div.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: white;
      border: 1px solid #e0e0e0;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 15px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      transition: all 0.3s ease;
    `;
    
    div.innerHTML = `
      <div style="display: flex; align-items: center; flex-grow: 1;">
        <img src="${p.imagen}" alt="${p.nombre}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 10px; margin-right: 20px;">
        <div style="flex-grow: 1;">
          <h5 style="margin: 0 0 10px 0; color: #333; font-weight: 600; font-size: 1.1rem;">${p.nombre}</h5>
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
            <button class="btn-cantidad-menos" onclick="cambiarCantidad(${index}, ${cantidad - 1})" style="width: 32px; height: 32px; border: 1px solid #ddd; background: white; border-radius: 8px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s;">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
            </button>
            <input type="number" min="1" value="${cantidad}" readonly style="width: 60px; text-align: center; border: 1px solid #ddd; border-radius: 8px; padding: 6px; font-weight: 600;">
            <button class="btn-cantidad-mas" onclick="cambiarCantidad(${index}, ${cantidad + 1})" style="width: 32px; height: 32px; border: 1px solid #ddd; background: white; border-radius: 8px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s;">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
            </button>
          </div>
          <p style="margin: 0; color: #666;">
            <strong style="color: #667eea;">$${precio.toFixed(2)}</strong> c/u | 
            Subtotal: <strong style="color: #333;">$${subtotal.toFixed(2)}</strong>
          </p>
        </div>
      </div>
      <button onclick="eliminarDelCarrito(${index})" style="background: #dc3545; color: white; border: none; padding: 10px 18px; border-radius: 10px; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; gap: 6px; font-weight: 600; margin-left: 15px;">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="3 6 5 6 21 6"></polyline>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        </svg>
        Eliminar
      </button>
    `;
    
    // Efectos hover
    div.addEventListener('mouseenter', function() {
      this.style.boxShadow = "0 4px 12px rgba(0,0,0,0.1)";
      this.style.transform = "translateY(-2px)";
    });
    div.addEventListener('mouseleave', function() {
      this.style.boxShadow = "0 2px 8px rgba(0,0,0,0.05)";
      this.style.transform = "translateY(0)";
    });
    
    container.appendChild(div);
    total += subtotal;
  });

  actualizarTotales(total);
  actualizarContador();
  deshabilitarBotones(false);
}

function actualizarTotales(total) {
  if (totalElemento) {
    totalElemento.innerText = "$" + total.toFixed(2);
  }
  if (subtotalElemento) {
    subtotalElemento.innerText = "$" + total.toFixed(2);
  }
}

function actualizarContador() {
  const totalItems = carrito.reduce((sum, item) => sum + Number(item.cantidad || 1), 0);
  
  if (cartCountElement) {
    cartCountElement.textContent = totalItems === 1 ? '1 item' : `${totalItems} items`;
  }
}

function deshabilitarBotones(deshabilitar) {
  const checkoutBtn = document.getElementById('checkout-btn');
  const clearBtn = document.getElementById('clear-cart-btn');
  
  if (checkoutBtn) {
    if (deshabilitar) {
      checkoutBtn.style.opacity = '0.5';
      checkoutBtn.style.pointerEvents = 'none';
      checkoutBtn.style.cursor = 'not-allowed';
    } else {
      checkoutBtn.style.opacity = '1';
      checkoutBtn.style.pointerEvents = 'auto';
      checkoutBtn.style.cursor = 'pointer';
    }
  }
  
  if (clearBtn) {
    if (deshabilitar) {
      clearBtn.style.opacity = '0.5';
      clearBtn.style.pointerEvents = 'none';
      clearBtn.style.cursor = 'not-allowed';
    } else {
      clearBtn.style.opacity = '1';
      clearBtn.style.pointerEvents = 'auto';
      clearBtn.style.cursor = 'pointer';
    }
  }
}

function cambiarCantidad(index, val) {
  const cantidad = Math.max(1, parseInt(val || 1, 10));
  carrito[index].cantidad = cantidad;
  localStorage.setItem("carrito", JSON.stringify(carrito));
  mostrarCarrito();
}

function eliminarDelCarrito(index) {
  if (confirm('¿Estás seguro de que deseas eliminar este producto?')) {
    carrito.splice(index, 1);
    localStorage.setItem("carrito", JSON.stringify(carrito));
    mostrarCarrito();
  }
}

function vaciarCarrito() {
  if (carrito.length === 0) {
    alert('El carrito ya está vacío');
    return;
  }
  
  if (confirm('¿Estás seguro de que deseas vaciar todo el carrito?')) {
    localStorage.removeItem("carrito");
    carrito = [];
    mostrarCarrito();
  }
}