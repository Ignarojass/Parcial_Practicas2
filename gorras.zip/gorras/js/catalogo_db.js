document.addEventListener('DOMContentLoaded', async () => {
  const container = document.querySelector('.productos-grid');
  container.innerHTML = '<p class="text-center">Cargando gorras desde la base...</p>';
  try {
    const res = await fetch('products_api.php');
    
    // 1. Convertir la respuesta a JSON y guardarla en la variable 'productos'
    const productos = await res.json(); 
    
    // 2. Ahora sí, llamar a la función render con los datos
    render(productos);
  } catch (e) {
    container.innerHTML = '<div class="alert alert-danger">No se pudo cargar el catálogo.</div>';
    console.error("Error al procesar la API:", e); // Opcional, pero útil para ver el error exacto
  }
});

function render(productos) {
  const mainContainer = document.querySelector('.productos-grid');
  mainContainer.innerHTML = '';
  
  productos.forEach(p => {
    const productDiv = document.createElement('section');
    productDiv.classList.add('product-details', 'col-12', 'col-md-6', 'col-lg-4', 'mb-4');

    const hayStock = Number(p.stock) > 0;
    const mensajeStock = hayStock ? `Stock: ${p.stock} unidades` : '¡AGOTADO!';
    
    // Usar data-attributes en lugar de onclick para mayor seguridad
    const botonHTML = hayStock
      ? `<button class="cta" 
                data-id="${p.id}"
                data-nombre="${p.nombre}"
                data-precio="${p.precio}"
                data-imagen="${p.imagen}">
            Agregar al carrito
          </button>`
      : `<button class="cta" disabled style="background-color: grey;">Sin Stock</button>`;

    productDiv.innerHTML = `
      <h2>${p.nombre}</h2>
      <img src="${p.imagen}" alt="${p.nombre}">
      <p class="mb-1">Precio: $${Number(p.precio).toFixed(2)}</p>
      <p style="color: ${hayStock ? 'green' : 'red'}; font-weight: bold;">${mensajeStock}</p>
      ${botonHTML}
    `;
    
    mainContainer.appendChild(productDiv);
  });

  // Agregar event listener para los botones (si usas data-attributes)
  agregarEventListeners();
}

// Función para manejar los eventos de los botones
function agregarEventListeners() {
  document.addEventListener('click', function(e) {
    if (e.target.classList.contains('cta') && !e.target.disabled) {
      const boton = e.target;
      agregarAlCarrito(
        boton.dataset.id,
        boton.dataset.nombre,
        Number(boton.dataset.precio),
        boton.dataset.imagen
      );
    }
  });
}