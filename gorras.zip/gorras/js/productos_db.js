// js/productos_db.js
function agregarAlCarrito(id, nombre, precio, imagen) {
  const producto = { id, nombre, precio, imagen, cantidad: 1 };
  let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
  // Si ya existe el producto, incremento cantidad
  const idx = carrito.findIndex(p => p.id === id);
  if (idx >= 0) { carrito[idx].cantidad = Number(carrito[idx].cantidad||1) + 1; }
  else { carrito.push(producto); }
  localStorage.setItem("carrito", JSON.stringify(carrito));
  window.location.href = "carrito.php";
}
