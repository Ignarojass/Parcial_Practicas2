<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title><?= isset($title) ? $title : 'Gorras a la Moda' ?></title>
  <link rel="icon" href="img/favicon.jpg" type="image/jpg">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/styles.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
<div class="top-bar">
  Bienvenidos a nuestra página web <div class="top-links">
    <a href=>Instituto Superior Manuel Belgrano</a>
  </div>
</div>

<header>
  <div class="header-content">
    <img src="https://images.vexels.com/media/users/3/207115/isolated/preview/db72ee0b472f4d5e0c3455c64d0ff45c-ilustracion-de-sombrero-de-gorra-de-pescador.png" alt="Logo" class="logo">
    <nav>
      <ul>
        <li><a class="<?= ($active??'')==='inicio'?'active':'' ?>" href="index.php">Inicio</a></li>
        <li><a href="index.php#about">Nosotros</a></li>
        <li><a class="<?= ($active??'')==='gorras'?'active':'' ?>" href="gorras.php">Gorras</a></li>
        <li><a class="<?= ($active??'')==='contacto'?'active':'' ?>" href="contacto.php">Contacto</a></li>
      </ul>
    </nav>
    <div class="search-cart">
      <input type="text" placeholder="Buscar">
      <a href="carrito.php">
        <img src="img/carrito.png" alt="Carrito" class="icon cart-icon">
      </a>
    </div>
  </div>
</header>
<main>
